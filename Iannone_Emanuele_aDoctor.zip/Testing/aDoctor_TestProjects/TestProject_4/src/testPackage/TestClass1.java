package testPackage;

public class TestClass1 {
    public void foo() {
        PowerManager.WakeLock wakeLock1 = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK | PowerManager.ON_AFTER_RELEASE, "wakelock1");
        wakeLock1.acquire();
        wakeLock1.release();
    }
}
